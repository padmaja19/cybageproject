$.ajax({
    url:"http://localhost:3000/blogs",
    method:"GET",
    success:(x)=>{
        console.log(x);
var allBlogs = x;
console.log(allBlogs[0].img);

const blogit = document.getElementsByClassName('blog')[0];
console.log(blogit);

function createCard() {
    // const card = document.createElement('div');
    // card.className = "row row-cols-1 row-cols-md-2";
    const card2 = document.createElement('div');
    card2.className = "col mb-4";

    const card3 = card2.appendChild(document.createElement('div'));
    card3.className = "card";

    const img = card3.appendChild(document.createElement('img'));
    img.className = "card-img-top";
    img.src = allBlogs[0].img;

    const card4 = card3.appendChild(document.createElement('div'));
    card4.className = "card-body";

    const h4 = card4.appendChild(document.createElement('h4'));
    h4.className = "card-title";
    h4.innerText = allBlogs[0].blogtitle;

    const card5 = card4.appendChild(document.createElement('div'));
    card5.className = "author";

    const p = card5.appendChild(document.createElement('p'));
    const em = p.appendChild(document.createElement('em'));
    em.innerText = "Author : " + allBlogs[0].blogtitle;

    const p2 = card4.appendChild(document.createElement('p'));
    p2.innerText = "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."
    const btn = card4.appendChild(document.createElement('a'));
    btn.className = "btn btn-primary";
    btn.href="#";
    btn.innerText="Read More";
    return card2;
}

blogit.appendChild(createCard());
blogit.appendChild(createCard());
blogit.appendChild(createCard());
blogit.appendChild(createCard());


// $.ajax({
//     method: "POST",
//     url: "http://localhost:3000/blogs",
//     data: JSON.stringify(data),
//     dataType: "text",
//     contentType: "application/json",

//   });

  

        // $("span#id1").append(x.data.first_name+ " "+x.data.last_name);
        // $("span#id2").append(x.data.email);
        // var img=x.data.avatar;
        // var drawimg="<img src='"+img+"'/>";
        // $("div#img").append(drawimg)
    },
    error:(e)=>{
        alert("Error: "+e)
    }
});



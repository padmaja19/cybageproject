import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrationsuccessdialog',
  templateUrl: './registrationsuccessdialog.component.html',
  styleUrls: ['./registrationsuccessdialog.component.scss']
})
export class RegistrationsuccessdialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

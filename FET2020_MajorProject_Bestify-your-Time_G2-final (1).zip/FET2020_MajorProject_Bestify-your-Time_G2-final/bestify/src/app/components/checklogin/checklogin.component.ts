import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checklogin',
  templateUrl: './checklogin.component.html',
  styleUrls: ['./checklogin.component.scss']
})
export class CheckloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
